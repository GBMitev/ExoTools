# %%
def states_df(path):
    from pandas import read_csv

    column_names = ["NN","E","gns","J","tau","e/f","Manifold","v","Lambda","Sigma","Omega"]
    df = read_csv(f"{path}", delim_whitespace = True,names = column_names)
    return df